CALCULADORA DE SERRALHERIA — SITE

Arquivos:
- index.html: site completo, sem necessidade de servidor.
- Abra index.html no navegador para testar.
- Para publicar no Netlify: arraste a pasta/ZIP para o painel do Netlify.

Observação:
Os preços iniciais e as fórmulas foram reproduzidos da planilha enviada. Os preços podem ser alterados no próprio site e ficam salvos no navegador do aparelho.
